# Braces & Aligners — Flutter App

This repository contains a Flutter app showcasing braces and aligners with favorites persisted locally.

## How to build (locally)
1. Install Flutter SDK
2. flutter pub get
3. flutter run

## Codemagic
This repo includes `codemagic.yaml` which runs `flutter create` during the build, then builds a release APK.
Connect this repo to Codemagic and start a build to get the APK.
