import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

void main() {
  runApp(OrthoOptionsApp());
}

class OrthoOptionsApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Ortho Options',
      theme: ThemeData(primarySwatch: Colors.blue),
      home: OrthoHomePage(),
    );
  }
}

class OrthoHomePage extends StatefulWidget {
  @override
  _OrthoHomePageState createState() => _OrthoHomePageState();
}

class _OrthoHomePageState extends State<OrthoHomePage> {
  List<String> options = ["Braces", "Aligners", "Lingual Braces"];
  List<String> favorites = [];

  @override
  void initState() {
    super.initState();
    _loadFavorites();
  }

  Future<void> _loadFavorites() async {
    final prefs = await SharedPreferences.getInstance();
    setState(() {
      favorites = prefs.getStringList('favorites') ?? [];
    });
  }

  Future<void> _toggleFavorite(String option) async {
    final prefs = await SharedPreferences.getInstance();
    setState(() {
      if (favorites.contains(option)) {
        favorites.remove(option);
      } else {
        favorites.add(option);
      }
      prefs.setStringList('favorites', favorites);
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Ortho Options')),
      body: ListView.builder(
        itemCount: options.length,
        itemBuilder: (context, index) {
          final option = options[index];
          final isFavorite = favorites.contains(option);
          return ListTile(
            leading: Icon(Icons.medical_services),
            title: Text(option),
            trailing: IconButton(
              icon: Icon(
                isFavorite ? Icons.favorite : Icons.favorite_border,
                color: isFavorite ? Colors.red : null,
              ),
              onPressed: () => _toggleFavorite(option),
            ),
          );
        },
      ),
    );
  }
}
