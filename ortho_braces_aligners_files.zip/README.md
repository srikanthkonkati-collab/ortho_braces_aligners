# Ortho Braces Aligners App

A simple **Flutter app** that showcases different orthodontic treatment options  
(Braces, Aligners, Lingual Braces) with the ability to **mark favorites**.  
The app stores favorite selections locally using `SharedPreferences`.

---

## 📱 Features
- List of orthodontic treatment options
- Favorite / Unfavorite options
- Persistent storage of favorites
- Clean UI built with Flutter
- Ready to build APK using Codemagic

---

## 🚀 Getting Started

### 1. Clone Repository
```bash
git clone https://github.com/<your-username>/ortho_braces_aligners.git
cd ortho_braces_aligners
```

### 2. Install Dependencies
```bash
flutter pub get
```

### 3. Run App (Debug)
```bash
flutter run
```

### 4. Build Release APK
```bash
flutter build apk --release
```

Or let **Codemagic** build automatically.

---

## 🛠 Codemagic CI/CD
This repo already includes a `codemagic.yaml` file.  
Steps:
1. Go to [https://codemagic.io](https://codemagic.io)  
2. Sign in with GitHub  
3. Add repo → `ortho_braces_aligners`  
4. Start build → Download **app-release.apk**  

---

## 👨‍⚕️ Author
- **Srikanth Konkati**  
  Doctor | Ortho Enthusiast | App Creator
